import { Link } from "react-router-dom";
import MainLayout from "@/components/MainLayout";
import { Pill } from "lucide-react";

const employees = [
  { id: 1, name: "Ihab" },
  { id: 2, name: "Bassam" },
  { id: 3, name: "Duha" },
  { id: 4, name: "Sarah" },
  { id: 5, name: "Muath" },
  { id: 6, name: "Mahmoud" },
  { id: 7, name: "Nzar" },
];

export default function Index() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8 sm:py-12">
        {/* Hero Section */}
        <div className="text-center mb-12 sm:mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Pill className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground">
              اختر الموظف
            </h1>
          </div>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
            اختر اسمك للدخول إلى جرد الأدوية الخاص بك
          </p>
        </div>

        {/* Employee Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
          {employees.map((employee) => (
            <Link
              key={employee.id}
              to={`/inventory/${employee.name.toLowerCase()}`}
              className="group"
            >
              <div className="relative overflow-hidden rounded-2xl bg-white dark:bg-slate-800 border border-border dark:border-slate-700 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-primary/30 cursor-pointer h-full p-6 sm:p-8 flex flex-col items-center justify-center text-center gap-4">
                {/* Gradient Background Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                {/* Avatar with First Letter */}
                <div className="relative z-10 w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-md">
                  <span className="text-4xl sm:text-5xl font-bold text-primary-foreground">
                    {employee.name.charAt(0).toUpperCase()}
                  </span>
                </div>

                {/* Name */}
                <h2 className="relative z-10 text-xl sm:text-2xl font-bold text-foreground">
                  {employee.name}
                </h2>

                {/* Hover Arrow */}
                <div className="relative z-10 text-primary text-2xl transform group-hover:translate-x-1 transition-transform duration-300">
                  →
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Info Section */}
        <div className="mt-16 sm:mt-20 p-6 sm:p-8 rounded-2xl bg-secondary/40 border border-primary/20 max-w-2xl mx-auto">
          <p className="text-center text-sm sm:text-base text-foreground">
            <span className="font-semibold">اختر اسمك أعلاه</span> للدخول إلى منطقة جردك
            الخاصة وإضافة أو تعديل الأدوية
          </p>
        </div>
      </div>
    </MainLayout>
  );
}
